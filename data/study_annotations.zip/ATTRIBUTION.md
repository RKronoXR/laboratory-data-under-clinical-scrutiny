# Attribution

Updated Refined DCBR lesion masks and proximal-side region annotations.

Authors: Ricardo Eugenio Gonzalez Valenzuela, Swasti Mishra, Pascal Mettes,
and Erwin Berkhout.

Please credit these authors, identify any changes made to the annotations, and
retain a link to the Creative Commons Attribution 4.0 International licence:
https://creativecommons.org/licenses/by/4.0/

Source radiographs: DCBR proximal caries lesions dataset,
https://doi.org/10.17632/4fbdxs7s7w.1

Use CITATION.cff in the accompanying study code repository for study authorship.
