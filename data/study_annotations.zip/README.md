# Updated Refined DCBR annotations

Annotation version: `refined-dcbr-updated`.

This annotation-only bundle contains 100 full-image binary lesion masks,
`Proximal_Side_Regions.csv` with 1,322 proximal-side regions, and
`Surface_Review_085.csv` with the 14 explicitly reviewed regions of bitewing 085.
It contains no radiographs. Image files must be obtained from the source dataset.

The annotations are the authors' intentionally updated release. They have a
separate exact-byte fingerprint profile in `configs/main/data_fingerprints_updated.json`.
They are not declared byte-identical to the recorded annotation profile used by
the saved reference predictions. Training with this profile produces an updated
experiment; its performance must be measured from the new run.

Use the repository's dataset assembler to combine these annotations with the
downloaded source datasets. The assembler selects required files by SHA256 and
copies their bytes without image decoding or re-encoding. It will not replace
a missing recorded mask with an updated mask.

For preprocessing, consume the surface-review metadata together with the full
mask and ROI coordinates. It preserves the explicitly reviewed target labels
where neighbouring lesion pixels enter another surface's bounding rectangle.
The repository data reader implements these decisions; an arbitrary bounding-box
cropper may not.

These authored annotation files are licensed under Creative Commons Attribution
4.0 International (CC BY 4.0). See LICENSE.txt and ATTRIBUTION.md. This licence
covers this authored annotation bundle, not the original radiographs.
